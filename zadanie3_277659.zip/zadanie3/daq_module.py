import nidaqmx
from nidaqmx.constants import AcquisitionType, LineGrouping
import threading
import time

class DAQAcquisition:
    def __init__(self, ai_channel="myDAQ3/ai0", di_channel="myDAQ3/port0/line0", sample_rate=1000):
        self.ai_channel = ai_channel
        self.di_channel = di_channel
        self.sample_rate = sample_rate
        self.is_running = False
        self.thread = None
        self.buffer = []
        self.buffer_lock = threading.Lock()
        self.start_time = 0

    def start(self):
        if self.is_running:
            return
        self.is_running = True
        self.start_time = time.time()
        self.thread = threading.Thread(target=self._acq_loop, daemon=True)
        self.thread.start()

    def stop(self):
        self.is_running = False
        if self.thread and self.thread.is_alive():
            self.thread.join()

    def _acq_loop(self):
        try:
            with nidaqmx.Task() as ai_task, nidaqmx.Task() as di_task:
                ai_task.ai_channels.add_ai_voltage_chan(self.ai_channel, min_val=-10.0, max_val=10.0)
                ai_task.timing.cfg_samp_clk_timing(rate=self.sample_rate, sample_mode=AcquisitionType.CONTINUOUS)
                
                di_task.di_channels.add_di_chan(self.di_channel, line_grouping=LineGrouping.CHAN_PER_LINE)
                
                samples_per_read = int(self.sample_rate * 0.1) # paczka danych co 100ms
                
                ai_task.start()
                di_task.start()
                
                while self.is_running:
                    ai_data = ai_task.read(number_of_samples_per_channel=samples_per_read)
                    di_data = di_task.read()
                    
                    # Formowanie paczki wymaganej przez główne GUI
                    paczka = {
                        'timestamp': time.time() - self.start_time,
                        'di': di_data,
                        'ai': ai_data
                    }
                    
                    with self.buffer_lock:
                        self.buffer.append(paczka)
                        
        except Exception as e:
            print(f"Błąd sprzętowy DAQ: {e}")
        finally:
            self.is_running = False

    def get_samples(self):
        with self.buffer_lock:
            data = self.buffer.copy()
            self.buffer.clear()
        return data